class YowConstants:
    DOMAIN       = "s.whatsapp.net"
    ENDPOINTS     = (
        ("e1.whatsapp.net", 443),
        ("e2.whatsapp.net", 443),
        ("e3.whatsapp.net", 443),
        ("e4.whatsapp.net", 443),
        ("e5.whatsapp.net", 443),
        ("e6.whatsapp.net", 443),
        ("e7.whatsapp.net", 443),
        ("e8.whatsapp.net", 443),
        ("e9.whatsapp.net", 443),
        ("e10.whatsapp.net", 443),
        ("e11.whatsapp.net", 443),
        ("e12.whatsapp.net", 443),
        ("e13.whatsapp.net", 443),
        ("e14.whatsapp.net", 443),
        ("e15.whatsapp.net", 443),
        ("e16.whatsapp.net", 443),
        )

    WHATSAPP_SERVER = "s.whatsapp.net"
    WHATSAPP_GROUP_SERVER = "g.us"

    PATH_STORAGE = "~/app-root/repo/logs/.yowsup"

    PREVIEW_WIDTH = 64
    PREVIEW_HEIGHT = 64
